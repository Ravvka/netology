# Ansible Collection - my_own_namespace.yandex_cloud_elk

Коллекция содержит собственный модуль `my_own_module` и роль `my_own_role`, создающие текстовый файл на удалённом хосте.

## Modules

### my_own_module

Создаёт текстовый файл на удалённом хосте.

| Параметр | Тип | Обязательный | По умолчанию | Описание |
|----------|-----|--------------|--------------|----------|
| `path`   | str | да           | —            | Полный путь к создаваемому файлу |
| `content`| str | нет          | `""`         | Содержимое, записываемое в файл |

Пример:

```yaml
- name: Create a file
  my_own_namespace.yandex_cloud_elk.my_own_module:
    path: /tmp/test.txt
    content: "Hello, world!"
```

## Roles

### my_own_role

Роль, использующая `my_own_module` для создания файла.

| Переменная                | По умолчанию               | Описание                    |
|---------------------------|----------------------------|-----------------------------|
| `my_own_module_path`      | `/tmp/my_own_role_file.txt`| Путь к создаваемому файлу   |
| `my_own_module_content`   | `Hello from my own role!`  | Содержимое файла            |

Пример:

```yaml
- hosts: localhost
  connection: local
  roles:
    - role: my_own_namespace.yandex_cloud_elk.my_own_role
```

## License

MIT