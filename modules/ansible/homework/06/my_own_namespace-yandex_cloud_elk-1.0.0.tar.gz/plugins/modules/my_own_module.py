#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2023, Ravvka <ravil@example.org>
# MIT License (see https://opensource.org/licenses/MIT)

from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

DOCUMENTATION = r'''
---
module: my_own_module
short_description: Creates a text file on the remote host
version_added: "1.0.0"
description:
    - This module creates a text file on the remote host at the path specified
      by the C(path) parameter, with the content specified by the C(content) parameter.
options:
    path:
        description: Full path of the file to create on the remote host.
        required: true
        type: str
    content:
        description: Content to write into the file.
        required: false
        type: str
        default: ""
author:
    - Ravvka (@ravvka)
'''

EXAMPLES = r'''
- name: Create a file
  my_own_namespace.yandex_cloud_elk.my_own_module:
    path: /tmp/test.txt
    content: "Hello, world!"
'''

RETURN = r'''
path:
    description: The path of the file that was created.
    type: str
    returned: always
    sample: /tmp/test.txt
content:
    description: The content that was written to the file.
    type: str
    returned: always
    sample: "Hello, world!"
state:
    description: Whether the file was created or already present.
    type: str
    returned: always
    sample: present
'''

from ansible.module_utils.basic import AnsibleModule


def run_module():
    module_args = dict(
        path=dict(type='str', required=True),
        content=dict(type='str', required=False, default='')
    )

    result = dict(
        changed=False,
        path='',
        content='',
        state=''
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    path = module.params['path']
    content = module.params['content']
    result['path'] = path
    result['content'] = content

    exists = False
    if __import__('os').path.exists(path):
        exists = True
        with open(path, 'r') as f:
            if f.read() == content:
                result['state'] = 'present'
                module.exit_json(**result)

    if module.check_mode:
        result['state'] = 'present'
        module.exit_json(**result)

    with open(path, 'w') as f:
        f.write(content)

    result['changed'] = True
    result['state'] = 'present'
    module.exit_json(**result)


def main():
    run_module()


if __name__ == '__main__':
    main()