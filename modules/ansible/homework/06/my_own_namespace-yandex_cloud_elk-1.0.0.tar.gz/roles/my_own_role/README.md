my_own_role
===========

Роль создаёт текстовый файл на хосте с помощью модуля `my_own_module`.

Requirements
------------

Установленная коллекция `my_own_namespace.yandex_cloud_elk`.

Role Variables
--------------

| Переменная              | По умолчанию                | Описание                  |
|-------------------------|-----------------------------|---------------------------|
| `my_own_module_path`    | `/tmp/my_own_role_file.txt` | Путь к создаваемому файлу |
| `my_own_module_content` | `Hello from my own role!`   | Содержимое файла          |

Example Playbook
----------------

    - hosts: localhost
      connection: local
      roles:
        - role: my_own_namespace.yandex_cloud_elk.my_own_role

License
-------

MIT

Author Information
------------------

Ravvka